

/**
 Main method used to start the program, provided by instructors.
 @author  CS213 Instructors
 @author Rizwan Chowdhury
 @author Tin Fung
 */
public class Prog1
{
   public static void main(String [] args){
      new ProjectManager().run();
   } 
}
